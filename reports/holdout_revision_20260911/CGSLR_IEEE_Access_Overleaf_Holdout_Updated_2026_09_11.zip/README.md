# IEEE Access manuscript: additional holdout update

Compile `main.tex` with pdfLaTeX in Overleaf. The archive includes the existing figure PDFs and template/font support files. Figure PDFs remain vector/text assets; no screenshot substitution was made.

This revision adds the completed 9,000-post same-source evaluation to the Phase 1 efficiency manuscript. Original experiments, result tables, and figures remain unchanged. New material comprises the holdout protocol, a main results table, Appendix F, and corresponding abstract/discussion/limitations/conclusion updates.

Review documents are in `revision/`. Raw post text, row-level predictions, model weights, and private credentials are not included.

This is a collaborator-review version, not a submission-certified manuscript. Author names, affiliations, corresponding-author details, funding/acknowledgment and applicable AI-use disclosure, and biographies still require author completion. The new result is same-source validation, not external-domain or clinical validation.
