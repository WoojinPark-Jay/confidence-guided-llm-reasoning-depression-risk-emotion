"""Build and package the same-source holdout manuscript revision."""
from pathlib import Path
import difflib
import hashlib
import json
import os
import re
import shutil
import subprocess
import zipfile
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent/'Paper_20260911_phase1_efficiency'
QA=ROOT.parent/'tmp/holdout_revision_qa_20260911'
QA.mkdir(parents=True,exist_ok=True)
TEX='/Users/woojinpark/.cache/codex-runtimes/codex-texlive/small/bin/universal-darwin'
TINY='/Users/woojinpark/Library/TinyTeX/texmf-dist'
CACHE='/Users/woojinpark/Library/Caches/Tectonic/bundles/data/6ffe055852f8faf66c0acbe1a7fb27f87b869a90bad1204f3bf4d9683f597c7c'
env=os.environ.copy()
env.update(TEXINPUTS=f'.:{TINY}/tex//:{CACHE}//:',TFMFONTS=f'.:{TINY}/fonts/tfm//:',
 VFFONTS=f'.:{TINY}/fonts/vf//:',T1FONTS=f'.:{TINY}/fonts/type1//:',ENCFONTS=f'.:{TINY}/fonts/enc//:',
 TEXFONTMAPS=f'.:/Users/woojinpark/Library/TinyTeX/texmf-var/fonts/map/pdftex/updmap//:{TINY}/fonts/map//:')
for i in range(3):
    p=subprocess.run([f'{TEX}/pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex'],cwd=ROOT,env=env,capture_output=True,text=True)
    (QA/f'build-{i+1}.log').write_text(p.stdout+p.stderr)
    if p.returncode: raise RuntimeError(p.stdout[-4000:])
old=(BASE/'main.tex').read_text();new=(ROOT/'main.tex').read_text()
tables=lambda s:re.findall(r'\\begin\{table\*?\}.*?\\end\{table\*?\}',s,re.S)
assert tables(new)[:len(tables(old))]==tables(old),'Original results tables changed'
assert len(tables(new))==len(tables(old))+1
assert old.split('\\begin{thebibliography}')[1].split('\\end{thebibliography}')[0]==new.split('\\begin{thebibliography}')[1].split('\\end{thebibliography}')[0]
for p in (BASE/'figures').iterdir():
    if p.is_file(): assert p.read_bytes()==(ROOT/'figures'/p.name).read_bytes()
diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='before/main.tex',tofile='after/main.tex'))
(ROOT/'HOLDOUT_FULL_DIFF.md').write_text('# 이번 추가 평가 반영 전후 전체 diff\n\n```diff\n'+diff+'```\n')
reader=PdfReader(ROOT/'main.pdf')
texts=[p.extract_text() or '' for p in reader.pages]
(QA/'page_text.txt').write_text('\n'.join(f'PAGE {i+1}\n{t}' for i,t in enumerate(texts)))
log=(ROOT/'main.log').read_text(errors='replace')
assert 'undefined references' not in log
warnings=re.findall(r'Overfull [^\n]+',log)
baseline_warnings=set(re.findall(r'Overfull [^\n]+',(BASE/'main.log').read_text(errors='replace')))
new_warnings=[w for w in warnings if w not in baseline_warnings]
assert not [w for w in new_warnings if '\\hbox' in w],new_warnings
assert all(float(re.search(r'\(([0-9.]+)pt',w).group(1))<2 for w in new_warnings),new_warnings
assert 'ADDITIONAL SAME-SOURCE HOLDOUT' in '\n'.join(texts)
report=dict(pages=len(texts),original_tables_unchanged=True,figures_unchanged=True,bibliography_unchanged=True,
 additional_tables=1,new_horizontal_overflow=0,minor_vertical_warnings=new_warnings,retained_template_warnings=sorted(set(warnings)-set(new_warnings)),undefined_references=0,
 visual_review='Pending current-build rendering',
 review_pages=[i+1 for i,t in enumerate(texts) if any(s in t for s in ['9,000','A6.','A6b.'])])
(ROOT/'holdout_qa.json').write_text(json.dumps(report,indent=2)+'\n')
pdf=ROOT.parent/'CGSLR_IEEE_Access_Holdout_Updated_2026_09_11.pdf'
shutil.copy2(ROOT/'main.pdf',pdf)
package=ROOT.parent/'CGSLR_IEEE_Access_Overleaf_Holdout_Updated_2026_09_11.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
    for p in ROOT.iterdir():
        if p.is_file() and (p.name in ['main.tex','references.bib','HOLDOUT_README.md'] or p.suffix in ['.cls','.sty','.pfb','.tfm','.map','.fd','.png']):
            z.write(p,'README.md' if p.name=='HOLDOUT_README.md' else p.name)
    for p in (ROOT/'figures').rglob('*'):
        if p.is_file(): z.write(p,p.relative_to(ROOT))
    for name in ['HOLDOUT_REVISION_REVIEW_KO.md','REMAINING_REVIEW_KO.md','HOLDOUT_FULL_DIFF.md','holdout_qa.json','build_holdout_revision.py']:
        if (ROOT/name).exists(): z.write(ROOT/name,'revision/'+name)
    data=ROOT.parent/'independent_evaluation_20260911/completed_review_verification.json'
    z.write(data,'revision/holdout_verified_aggregate.json')
with zipfile.ZipFile(package) as z:
    assert z.testzip() is None
    assert z.read('main.tex')==(ROOT/'main.tex').read_bytes()
(ROOT/'holdout_release_sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [pdf,package]},indent=2)+'\n')
print(json.dumps(report,indent=2))
