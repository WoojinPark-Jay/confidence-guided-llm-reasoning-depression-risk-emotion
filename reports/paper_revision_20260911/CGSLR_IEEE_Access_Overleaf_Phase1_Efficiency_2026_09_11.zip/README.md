# IEEE Access: Phase 1 performance and efficiency update

Revision: 2026-09-11. Base manuscript: reference-reviewed revision, 2026-09-09.

- Main file: `main.tex`; compiler: pdfLaTeX. Recompile from scratch and rerun for cross-references.
- The final research-team three-seed comparison and A100 efficiency benchmark are incorporated.
- Table 1 contains predictive-performance and inference-efficiency panels. Appendix A1d records resource accounting and the benchmark protocol.
- Figure 2 is updated as selectable-text vector PDF and editable SVG. Other figures, the final draw.io architecture, and downstream results are unchanged.
- The separately running 9,000-post evaluation is not part of this revision.

Review documents in this folder (under `revision/` in the Overleaf ZIP):
- `REVISION_REPORT_KO.md`: rationale, before/after values, and scope.
- `SENTENCE_CHANGES_KO.md`: actual before/after manuscript paragraphs and tables.
- `MANUSCRIPT_FULL_DIFF.md`: exact LaTeX diff.
- `phase1_final_results.json` and `.csv`: figure and inference-summary values.

The local source folder additionally retains the preceding reference audit documents and `QA_RESULT_KO.md`. The reference audit documents describe the 2026-09-09 reference-review stage, not a new reference audit.

Before submission, complete author, affiliation, corresponding-author, funding, and any other administrative placeholders. Institutional approval or independent validation has not been invented. The publisher's volume/year template metadata is not the experiment date.
