# [1/2] Phase 1 GPU 효율 벤치마크 — 결과 정리 (2026-09-11 최종 실행)

출처: `notebooks/colab/{distilbert,llama,mistral}_classification_fine_tuned_gpu_output.ipynb` (2026-09-11 실행)
짝 문서: `docs/paper_efficiency_insertion_plan_ko.md`

**이 실행이 논문에 싣을 최종본입니다.**

> **이번 실행에서 닫힌 것**
>
> - ✅ **가속기 통일** — 세 노트북 모두 `NVIDIA A100-SXM4-40GB`. 이전의 80GB/40GB 불일치 해소
> - ✅ **단일 측정 → 3회 반복** — 처리량·지연에 mean ± SD가 붙음
> - ✅ **측정 창 0.10초 → 2.4초** — DistilBERT 추론 GPU util이 0%에서 **57%**로 정상 기록
> - ✅ **정확도와 비용이 같은 실행** — "별도 실행" 각주 불필요
>
> **남은 공백**: Phase 2 생성 비용 미측정 (`RUN_GENERATION_BENCHMARK = False`)

---

## 1. 한 장 요약

| 항목 | DistilBERT | Llama 2 7B | Mistral 7B |
|---|---|---|---|
| 가속기 | A100-SXM4-40GB | A100-SXM4-40GB | A100-SXM4-40GB |
| 학습 대상 파라미터 | 66,955,779 (인코더 전체) | 12,288 (linear head) | 12,288 (linear head) |
| **test accuracy (3 seed)** | **96.88 ± 0.04** | 95.17 ± 0.07 | 95.36 ± 0.08 |
| **test macro F1 (3 seed)** | **96.88 ± 0.04** | 95.17 ± 0.07 | 95.36 ± 0.08 |
| Feature 추출 (GPU-h) | — | 0.64 | 0.67 |
| 하이퍼파라미터 탐색 (GPU-h) | 0.32 | 0.03 | 0.02 |
| 학습 3 seed (GPU-h) | 0.27 | 0.01 | 0.003 |
| **1회성 비용 합계 (GPU-h)** | **0.59** | **0.68** | **0.70** |
| 학습 peak memory (GB) | 4.35 | 1.11 | 1.11 |
| **배치 추론 처리량 (posts/s)** | **4,959.5 ± 15.5** | 55.5 ± 0.0 | 51.7 ± 0.0 |
| **단건 지연 p50 (ms)** | **4.80 ± 0.03** | 34.05 ± 0.10 | 36.62 ± 0.06 |
| **단건 지연 p95 (ms)** | **5.11 ± 0.12** | 36.23 ± 0.40 | 38.37 ± 0.18 |
| 추론 peak memory (GB) | **0.29** | 14.05 | 15.22 |
| 1,000건당 Phase 1 GPU-h | **0.000056** | 0.005008 | 0.005376 |
| 총 GPU 시간 / 에너지 | 0.61 h / 125 Wh | 0.87 h / 311 Wh | 0.91 h / 336 Wh |

**핵심 세 문장.**

- **만드는 비용은 셋이 비슷합니다** (0.59 ~ 0.70 GPU-h). 7B probe는 head만 학습하지만 108,000행
  backbone forward pass에 0.64~0.67 GPU-h를 먼저 지불하므로, DistilBERT의 전체 fine-tuning과
  총액이 맞먹습니다. DistilBERT가 오히려 **가장 쌉니다.**
- **쓰는 비용은 두 자릿수 배 차이입니다.** 1,000건당 Phase 1 GPU 시간 기준 DistilBERT가
  Llama 2 대비 **89.4×**, Mistral 대비 **96.0×** 저렴합니다. 처리량 비도 동일하게 89.4× / 95.9×,
  단건 지연은 7.1× / 7.6×, 추론 메모리는 **48× / 52×**입니다.
- **반복 측정이 안정적입니다.** 3회 반복의 SD가 처리량 0.3%(DistilBERT), 0.0%(7B 2종),
  지연 p50 0.2~0.6%에 불과합니다. 단일 측정이 아니라는 점을 논문에 밝힐 수 있습니다.

---

## 2. 정확도

### test (12,000행, seed 42/43/44)

| 모델 | seed 42 | 43 | 44 | mean ± SD | 95% CI |
|---|---|---|---|---|---|
| **DistilBERT** | 96.92 | 96.84 | 96.89 | **96.88 ± 0.04** | [96.79, 96.98] |
| Mistral 7B | 95.29 | 95.35 | 95.45 | 95.36 ± 0.08 | [95.16, 95.56] |
| Llama 2 7B | 95.24 | 95.11 | 95.15 | 95.17 ± 0.07 | [94.99, 95.34] |

(macro F1 기준. 3클래스 균형 test set이라 accuracy와 사실상 동일합니다.)

### 선택된 하이퍼파라미터

| 모델 | learning rate | batch | epochs | weight decay | prior 내 위치 |
|---|---|---|---|---|---|
| DistilBERT | 4.037e-05 | 64 | 3 | 1e-3 | 하단에서 59% |
| Llama 2 7B | 4.151e-04 | 32 | 3 | 1e-4 | 하단에서 31% |
| Mistral 7B | 2.399e-04 | 64 | 2 | 1e-4 | 하단에서 19% |

### ⚠️ 2·3위는 통계적으로 분리되지 않습니다

**Mistral [95.16, 95.56]과 Llama 2 [94.99, 95.34]의 신뢰구간이 겹칩니다**(95.16~95.34 구간).
차이는 0.19 pp이고 SD가 각각 0.08 / 0.07이므로, **이 비교로 두 probe의 우열을 주장할 수
없습니다.** 논문에서 순위를 단정하는 문장은 반드시 고쳐야 합니다(짝 문서 2-5절).

DistilBERT의 1위는 2위와 **1.52 pp** 차이에 구간이 완전히 분리되어 **견고합니다.**

---

## 3. 단계별 실측

가격은 `PRICE_BASIS = "colab"`, **1.1758 USD/GPU-h**(Colab compute unit 환산, 2026-09-08 기준)
입니다. 목록가이며 실제 청구액이 아닙니다.

### DistilBERT (전체 fine-tuning)

| stage | 시간 | 예제 | 처리량 | GPU util | peak mem | 에너지 |
|---|---|---|---|---|---|---|
| hyperparameter_sweep (4 trial) | 19.03분 | — | — | 54.9% | 4.35 GB | 62.4 Wh |
| train_seed_42 / 43 / 44 | 5.49 / 5.50 / 5.49분 | 252,000 each | 764 ex/s | 59% | 4.35 GB | 20.4 / 19.4 / 20.4 Wh |
| scoring_{val,test} × 3 seed | 각 0.13분 | 12,000 | ~1,510 ex/s † | 33~38% | 1.26 GB | ~0.23 Wh each |
| **inference_batched × 3** | 각 0.040분 | 12,000 | **4,975 / 4,944 / 4,959** | **57%** | 0.29 GB | 0.167 / 0.157 / 0.165 Wh |
| **inference_latency_batch1 × 3** | 각 0.042분 | 512 | 191 / 204 / 203 | 9% | 0.16 GB | ~0.040 Wh each |
| **합계** | **0.61 GPU-h** | | | | | **124.6 Wh** ($0.72) |

### Llama 2 7B (frozen backbone + linear probe)

| stage | 시간 | 예제 | 처리량 | GPU util | peak mem | 에너지 |
|---|---|---|---|---|---|---|
| **feature_extraction** | 38.43분 | 108,000 | 46.8 ex/s | 93.3% | **27.01 GB** | 234.9 Wh |
| hyperparameter_sweep | 1.59분 | — | — | 5.1% | 1.11 GB | 1.3 Wh |
| train_seed_42/43/44 | 각 ~0.19분 | 252,000 each | ~22,100 ex/s | 12~13% | 1.11 GB | ~0.15 Wh each |
| scoring × 6 | ~0.001초 | 12,000 | (해석 불가†) | 13~14% | 1.11 GB | 0 |
| **inference_batched × 3** | 각 3.61분 | 12,000 | **55.5 / 55.5 / 55.5** | 99.7% | 14.05 GB | ~23.8 Wh each |
| **inference_latency_batch1 × 3** | 각 ~0.29분 | 512 | 28.8 / 29.1 / 29.2 | 55% | 13.27 GB | ~0.96 Wh each |
| **합계** | **0.87 GPU-h** | | | | | **310.8 Wh** ($1.03) |

### Mistral 7B (frozen backbone + linear probe)

| stage | 시간 | 예제 | 처리량 | GPU util | peak mem | 에너지 |
|---|---|---|---|---|---|---|
| **feature_extraction** | 40.41분 | 108,000 | 44.5 ex/s | 93.7% | **29.11 GB** | 255.1 Wh |
| hyperparameter_sweep | 1.23분 | — | — | 11.0% | 1.11 GB | 1.1 Wh |
| train_seed_42/43/44 | 각 ~0.065분 | 168,000 each | ~43,400 ex/s | 10~12% | 1.11 GB | ~0.043 Wh each |
| scoring × 6 | ~0.001초 | 12,000 | (해석 불가†) | 14% | 1.11 GB | 0 |
| **inference_batched × 3** | 각 3.87분 | 12,000 | **51.7 / 51.7 / 51.7** | 99.7% | 15.22 GB | ~25.5 Wh each |
| **inference_latency_batch1 × 3** | 각 ~0.32분 | 512 | 26.9 / 27.0 / 27.1 | 57% | 14.28 GB | ~0.93 Wh each |
| **합계** | **0.91 GPU-h** | | | | | **335.7 Wh** ($1.07) |

### † `scoring_*`은 세 모델 **모두** 배포 처리량이 아닙니다

학습 파이프라인의 평가 단계이며, 성격이 모델마다 다릅니다.

- **DistilBERT (~1,510 ex/s)** — `trainer.predict()` 경로라 로짓 CPU 수집과 메트릭 계산
  오버헤드가 포함되고, batch 64·학습 정밀도에서 돕니다. 그래서 **같은 모델인데**
  scoring 1,510 ex/s와 `inference_batched` 4,959 ex/s로 **3.3배 차이**가 납니다.
- **두 probe (~10⁷ ex/s)** — GPU에 상주하는 4096차원 feature에 3×4096 선형 head만 곱한
  시간이라 **backbone forward pass가 통째로 빠져 있습니다.** 실제 건당 비용은
  `inference_batched`의 55.5 / 51.7 ex/s입니다.

**세 모델의 scoring 행을 한 표에 나란히 두면 대소 관계가 뒤집힙니다** — DistilBERT
1,510 ex/s vs probe 10⁷ ex/s로, DistilBERT가 7,000배 **느려** 보입니다. 논문 주장과 정반대
방향입니다. Appendix Table A1d에서 probe의 scoring 행을 제외한 이유가 이것이고,
DistilBERT의 scoring 행도 처리량 수치로 인용하면 안 됩니다.

**규칙: 배포 수치는 세 모델 모두 `inference_batched`(처리량)와
`inference_latency_batch1`(지연)에서만 가져옵니다.**

---

## 4. 캐스케이드 투영 (1,000건당)

Phase 2 생성 비용은 이번에도 측정하지 않았으므로 Phase 1 열만 있습니다.

| 운영점 | 라우팅률 | 1,000건 중 라우팅 | Phase 1 GPU-h / 1,000건 (DistilBERT) |
|---|---|---|---|
| phase1_only | 0% | 0 | 0.000056 |
| reddit_held_out | 1.425% | 14.25 | 0.000056 |
| mixed_emotion | 14.667% | 146.67 | 0.000056 |
| llm_for_every_post | 100% | 1,000 | 0.000056 |

**네 행이 동일한 것이 핵심입니다.** 라우팅을 줄여도 분류기 forward pass는 1,000건 전부가
지불합니다. "LLM 호출 98.58% 감소"를 "GPU 시간 98.58% 감소"로 바꿔 쓸 수 없습니다.

---

## 5. 논문 인용 시 주의

| 수치 | 인용 가능 여부 |
|---|---|
| accuracy / macro F1 / CI | ✅ |
| 처리량·지연 (mean ± SD, 3회) | ✅ **이번에 확보** |
| 1회성 GPU-h, peak memory, 에너지 | ✅ |
| DistilBERT 추론 GPU util (57%) | ✅ **이번에 정상화** (이전 실행은 0%) |
| `scoring_*` 처리량 (세 모델 전부) | ❌ 배포 측정 아님. 나란히 두면 대소가 뒤집힘 |
| Phase 2 건당 비용·절감률 | ❌ 미측정 |
| 두 probe의 우열 | ❌ CI 중첩 |
| USD 금액 | △ 목록가. 본문 표 대신 각주로 |

**남은 작업은 Phase 2 생성 비용 하나입니다.** llama 노트북에서
`RUN_GENERATION_BENCHMARK = True`로 1회(20~35분) 측정하면 "GPU 시간 x% 절감"까지 주장
가능해집니다. 하지 않으면 호출 수 감소까지만 보고하게 되며, 그 경우 짝 문서 2-3절의
문장을 그대로 쓰면 됩니다.

---

## 6. 산출물

각 모델의 `OUTPUT_DIR/efficiency/` 아래:
`efficiency_records.jsonl` / `.csv`, `efficiency_stages.csv`, **`inference_repeats.csv`**(신규),
`cascade_projection.csv`, `efficiency_summary.json`, `paper_rows.tex`.

루트: `/content/drive/MyDrive/confidence_guided_llm_reasoning/{distilbert,llama,mistral}_classification_fine_tuned/`

`paper_rows.tex`의 처리량·지연은 **3회차 값**입니다(`stage_value()`가 마지막 레코드를 집음).
논문에는 `inference_repeats.csv`의 mean ± SD를 쓰세요 — 1절 표가 그 값입니다.
