# [2/2] 논문 삽입 계획 — 절별 추가·수정 문장

대상 원고: `Confidence_Guided_Selective_LLM_Re_Evaluation_..._0907_.pdf` (28쪽)
근거 데이터: `docs/phase1_gpu_efficiency_benchmark_results_ko.md` (2026-09-11 실행)

이번 수정은 두 갈래입니다.

- **A. Table 1 교체** — 새 실행 수치로 정확도·하이퍼파라미터·순위 서술 갱신
- **B. 효율 신설** — 본문에는 문장만, 수치 상세는 Appendix Table A1d

**표·그림 번호는 하나도 바뀌지 않습니다.** Table 1~7, Figure 1~6 전부 그대로이고,
Appendix에 A1d 하나만 추가됩니다.

---

## 0. 전체 변경 목록

| # | 위치 | 작업 | 갈래 | 필수 |
|---|---|---|---|---|
| 1 | Table 1 본체 | 수치 교체 | A | 필수 |
| 2 | VII-A 1~2번째 문단 | 수치·순위 서술 교체 | A | 필수 |
| 3 | Figure 2 | **재생성** (수치가 그림에 박혀 있음) | A | 필수 |
| 4 | Appendix Table A1c | 하이퍼파라미터 3행 교체 | A | 필수 |
| 5 | VII-G RQ1a·RQ1b 문장 | 수치 교체 + 순위 단정 제거 | A | 필수 |
| 6 | Abstract | 수치 교체 | A | 필수 |
| 7 | VII-A 끝 | 효율 문단 + 각주 신설 | B | 필수 |
| 8 | VI-A 마지막 문장 | 교체 | B | 필수 |
| 9 | VII-G 효율 문장 | 교체 | B | 필수 |
| 10 | VIII Limitations | 교체 | B | 필수 |
| 11 | Appendix Table A1d | 신설 | B | 필수 |
| 12 | VI-F | 문구 수정 | B | 권장 |
| 13 | II. Contributions | 문장 추가 | B | 권장 |

**downstream은 손대지 않습니다.** 라우팅·캘리브레이션·Phase 2는 독립적으로 고정된
operational checkpoint(96.69%)를 쓰므로 Table 2~7, Figure 3~6은 영향이 없습니다.

---

# A. Table 1 교체

## 1. Table 1 본체 【필수】

**현재**

| Model | Accuracy, mean±SD | Accuracy 95% CI | Macro F1, mean±SD | Macro F1 95% CI |
|---|---|---|---|---|
| DistilBERT | 96.90±0.12% | [96.60, 97.20]% | 96.90±0.12% | [96.60, 97.19]% |
| Mistral 7B | 95.56±0.11% | [95.29, 95.83]% | 95.56±0.11% | [95.30, 95.82]% |
| Llama 2 7B | 95.09±0.06% | [94.94, 95.24]% | 95.09±0.06% | [94.94, 95.24]% |

**교체**

| Model | Accuracy, mean±SD | Accuracy 95% CI | Macro F1, mean±SD | Macro F1 95% CI |
|---|---|---|---|---|
| DistilBERT | 96.88±0.04% | [96.79, 96.98]% | 96.88±0.04% | [96.79, 96.98]% |
| Mistral 7B | 95.36±0.08% | [95.15, 95.57]% | 95.36±0.08% | [95.16, 95.56]% |
| Llama 2 7B | 95.17±0.07% | [95.00, 95.34]% | 95.17±0.07% | [94.99, 95.34]% |

**Note 문장에 한 문장 추가** (기존 note는 유지)

> The two 7B probes are not separated at this level: their confidence intervals
> overlap, and the table supports the selection of DistilBERT rather than an
> ordering of the probes.

## 2. VII-A 1~2번째 문단 【필수】

### 2-1. 수치 문단

**현재**
> Figure 2 visualizes the same observed three-seed results and their 95%
> confidence intervals. DistilBERT achieved 96.90± 0.12% accuracy, compared with
> 95.56± 0.11% for Mistral and 95.09± 0.06% for Llama 2. Macro F1 followed the
> same ordering. Under this fixed comparison protocol, DistilBERT exceeded
> Mistral and Llama 2 by 1.34 and 1.81 percentage points in mean accuracy,
> respectively.

**교체**
> Figure~2 visualizes the same observed three-seed results and their 95\%
> confidence intervals. DistilBERT achieved 96.88 $\pm$ 0.04\% accuracy, compared
> with 95.36 $\pm$ 0.08\% for Mistral and 95.17 $\pm$ 0.07\% for Llama~2. Macro F1
> followed the same ordering. Under this fixed comparison protocol, DistilBERT
> exceeded Mistral and Llama~2 by 1.52 and 1.71 percentage points in mean
> accuracy, respectively. The gap between the two probes is 0.19 points and their
> confidence intervals overlap, so the comparison separates DistilBERT from both
> probes but does not order the probes against each other.

**마지막 문장이 이번 교체의 핵심입니다.** 새 CI가 Mistral [95.15, 95.57], Llama 2
[95.00, 95.34]로 **95.15~95.34 구간에서 겹칩니다.** 이 사실을 밝히지 않고 두 수치를
나란히 제시하면 독자가 순위에 의미를 둡니다.

### 2-2. 오류 구성 문단

**현재**
> Depression–Happy confusions accounted for 75.4% of Llama 2 errors and 74.2% of
> Mistral errors across pooled seed predictions; Neutral F1 exceeded 98% for both.

**교체** (새 실행에서 재계산한 값)
> Depression--Happy confusions accounted for 75.6\% of Llama~2 errors and 74.3\%
> of Mistral errors across pooled seed predictions, and 72.8\% of DistilBERT
> errors; Neutral F1 exceeded 98\% for all three.

산출 근거 (3 seed 합산 혼동행렬)

| 모델 | 총 오류 | Depression↔Happy | 비중 | Neutral F1 (3 seed 평균) |
|---|---|---|---|---|
| DistilBERT | 1,122 | 817 | 72.8% | 98.69% |
| Llama 2 | 1,740 | 1,316 | 75.6% | 98.13% |
| Mistral | 1,670 | 1,240 | 74.3% | 98.21% |

**결론은 그대로입니다** — 세 모델의 오류 구조가 사실상 동일하고, 약 3/4이 Depression과
Happy 경계에 몰려 있습니다. 이 문단이 Phase 2 라우팅 설계의 근거이므로 논지가 유지됩니다.

### 2-3. 클래스별 F1 (필요 시 인용)

| 모델 | Depression | Neutral | Happy |
|---|---|---|---|
| DistilBERT | 95.99 | 98.69 | 95.66 |
| Mistral 7B | 93.93 | 98.21 | 93.49 |
| Llama 2 7B | 93.84 | 98.13 | 93.23 |

### 2-4. 그대로 두는 문장

> "DistilBERT had the highest mean score and approximately 66 million parameters,
> compared with about seven billion for each comparator."

> "The matched comparison and the downstream experiment serve different purposes.
> ... the latter retains the independently fixed operational DistilBERT checkpoint
> with 96.69% accuracy."

**96.69%는 건드리지 마세요.** 이번 실행과 무관한 독립 체크포인트이고, 모든 downstream
결과가 여기에 걸려 있습니다.

## 3. Figure 2 재생성 【필수】

막대에 값이 박혀 있습니다: `96.90 / 95.56 / 95.09` → **`96.88 / 95.36 / 95.17`**.
오차 막대도 SD가 바뀌어 폭이 달라집니다(DistilBERT 0.12 → 0.04로 크게 좁아짐).

캡션은 그대로 쓸 수 있지만, 축 절단 범위를 재조정하셔야 합니다. 새 값은 95.0~97.0
구간에 모이고 DistilBERT의 오차 막대가 매우 좁아져, 기존 축(94.5~97.5)이면 두 probe의
구간 중첩이 눈에 잘 안 보입니다. **중첩이 보이도록** 축을 잡으시길 권합니다 — 본문에서
중첩을 서술하는데 그림이 반대로 읽히면 안 됩니다.

## 4. Appendix Table A1c 【필수】

**현재**

| Model | Training | Learning rate | Batch | Epochs | Weight decay |
|---|---|---|---|---|---|
| DistilBERT | Full fine-tuning | 5.717×10⁻⁵ | 32 | 2 | 10⁻³ |
| Llama 2 7B | Linear probe | 2.824×10⁻⁴ | 64 | 3 | 10⁻⁴ |
| Mistral 7B | Linear probe | 2.292×10⁻⁴ | 16 | 2 | 10⁻² |

**교체**

| Model | Training | Learning rate | Batch | Epochs | Weight decay |
|---|---|---|---|---|---|
| DistilBERT | Full fine-tuning | 4.037×10⁻⁵ | 64 | 3 | 10⁻³ |
| Llama 2 7B | Linear probe | 4.151×10⁻⁴ | 32 | 3 | 10⁻⁴ |
| Mistral 7B | Linear probe | 2.399×10⁻⁴ | 64 | 2 | 10⁻⁴ |

**Note는 그대로 유지합니다.** 특히 "The downstream calibration and routing analyses
retained the independently fixed operational DistilBERT checkpoint (learning rate
8.996×10⁻⁵, batch 32, three epochs, weight decay 10⁻²), which achieved 96.69%
held-out accuracy" 문장은 **수정 대상이 아닙니다.**

## 5. VII-G — RQ1a·RQ1b 문장 【필수】

**현재**
> For RQ1b, the completed three-seed comparison retained DistilBERT: its mean
> held-out accuracy and macro F1 were both 96.90%, compared with 95.56% for the
> Mistral frozen-backbone probe and 95.09% for the Llama 2 probe. This is
> evidence for the operational choice under the bounded comparison, not a ranking
> of maximally tuned architectures.

**교체**
> For \textbf{RQ1b}, the completed three-seed comparison retained DistilBERT: its
> mean held-out accuracy and macro F1 were both 96.88\%, compared with 95.36\% for
> the Mistral frozen-backbone probe and 95.17\% for the Llama~2 probe, whose
> intervals overlap each other. This is evidence for the operational choice under
> the bounded comparison, not a ranking of maximally tuned architectures or of the
> two probes against each other.

## 6. Abstract 【필수】

**현재**
> In a three-seed comparison on the same 12,000 Reddit test posts, DistilBERT
> achieved 96.90 ± 0.12% accuracy, versus 95.56± 0.11% for Mistral 7B and
> 95.09 ± 0.06% for Llama 2 7B frozen-backbone linear probes.

**교체**
> In a three-seed comparison on the same 12{,}000 Reddit test posts, DistilBERT
> achieved 96.88 $\pm$ 0.04\% accuracy, versus 95.36 $\pm$ 0.08\% for Mistral 7B
> and 95.17 $\pm$ 0.07\% for Llama 2 7B frozen-backbone linear probes, while
> scoring roughly ninety times more posts per second than either probe under a
> controlled benchmark.

**주의.** 초록에 "89.4×" 같은 **비율 숫자는 쓰지 않습니다.** 시스템 전체 절감률로
읽힐 위험이 있는데 실제로는 Phase 1 분류기끼리의 비교이고 Phase 2는 미측정입니다.
"roughly ninety times" 정도의 서술이 안전합니다. 지면이 빠듯하면 이 절은 생략하고
본문에만 두셔도 됩니다.

---

# B. 효율 신설

## 7. VII-A 끝 — 새 문단 + 각주 【필수】

### 넣는 자리

VII-A 마지막 문단("...All subsequent results refer to that single operational
checkpoint.") **바로 뒤**, VII-B로 넘어가기 전.

### 왜 여기인가

같은 절에 "approximately 66 million parameters, compared with about seven billion
for each comparator. These results support retaining it for the tested pipeline"가
있는데, **파라미터 수가 비용의 유일한 근거**로 쓰이고 있습니다. 파라미터 수는 비용의
대리 지표이지 비용이 아닙니다.

### 추가할 문단

> **Computational cost of the Phase 1 router.** Retaining DistilBERT is an
> operational choice about per-post cost rather than about training cost.
> Building the three classifiers consumed comparable one-off compute --- 0.59
> GPU-hours for DistilBERT against 0.68 and 0.70 for the Llama~2 and Mistral
> probes --- because the frozen 7B backbones require a 0.64--0.67 GPU-hour
> feature-extraction pass before any linear head is trained. Inference cost,
> which is paid on every input, differs by two orders of magnitude. Under a
> controlled benchmark on a single A100-SXM4-40GB at fp16 with a 256-token cap,
> repeated three times over the full held-out split, DistilBERT scored
> 4{,}959.5 $\pm$ 15.5 posts per second in batches of 32 within a 0.29~GB
> footprint, at a median single-post latency of 4.80 $\pm$ 0.03~ms; the Llama~2
> and Mistral probes scored 55.5 and 51.7 posts per second at 14.05 and
> 15.22~GB, with medians of 34.05 and 36.62~ms. Per 1{,}000 posts this is
> 0.000056 Phase~1 GPU-hours for DistilBERT against 0.005008 and 0.005376 for the
> probes, factors of 89.4 and 96.0. The three architectures are therefore
> separated far more sharply by deployment cost than by the 1.5--1.7 percentage
> points of accuracy in Table~1. Appendix Table~A1d reports the per-stage
> measurements and the benchmark protocol.

### 각주 【필수】

> All three classifiers were profiled on the same accelerator model
> (A100-SXM4-40GB) in the same software environment, and the inference benchmark
> was repeated three times per model; the reported spread is across those
> repetitions. Monetary figures are omitted from the main text because the
> available rate is a list price rather than an invoice.

**이전 계획에 있던 "별도 실행" 각주는 더 이상 필요 없습니다.** 이번에는 정확도와 비용이
같은 실행, 같은 카드에서 나왔습니다.

## 8. VI-A COMPUTING ENVIRONMENT — 마지막 문장 교체 【필수】

**현재**
> Hardware-dependent timing is not reported as a comparative result because the
> runs were not executed under a controlled latency benchmark.

**교체**
> Phase~1 cost was measured under a controlled benchmark on a single
> A100-SXM4-40GB: NVML sampled GPU utilisation, memory and board power at 1~Hz
> around CUDA-synchronised timed regions, warm-up batches were discarded so that
> one-off autotuning was not charged to every post, the host-to-device copy was
> kept inside the timed region because a deployed scorer pays for it, input
> tokens were counted excluding padding, and the whole inference benchmark was
> repeated three times. Phase~2 generation was not instrumented; its cost is
> reported as the number of escalated posts and the number of generation calls
> each one issues.

**이 교체를 빠뜨리면 원고가 자기모순에 빠집니다** — 7번 문단이 통제된 벤치마크를
제시하는데 여기서는 그런 벤치마크가 없다고 말하게 됩니다.

### 함께 넣을 것 — 결정론에 대한 입장 (권장)

같은 절에 한 문장 더 두시면 재현성 질문이 미리 닫힙니다.

> Data sampling, splitting, model initialisation and batch order are seeded, and
> the classifier is re-seeded immediately before initialisation. Deterministic
> CUDA kernels were not forced: doing so disables the fast reduction paths a
> deployed scorer would use and would therefore misreport the cost this benchmark
> measures. Run-to-run training variation is instead quantified by the spread
> across seeds 42, 43 and 44.

## 9. VII-G — 효율 문장 교체 【필수】

**현재** (다음 문단의 세 번째 문장만 교체)
> Only 1.42% of Reddit posts and 14.67% of Mixed Emotion examples underwent
> re-evaluation. These are fractions of inputs, not counts of individual LLM
> calls: CoT and SELF-DISCOVER can require multiple generation stages per routed
> post. **Wall-clock time, token use, energy, and monetary cost were not
> benchmarked.** The stress-test routing rate characterizes its constructed
> scenario mix, not an expected deployment workload.

**교체**
> Phase~1 wall-clock time, throughput, latency, memory and energy were
> benchmarked and are reported in Section~VII-A; Phase~2 was not instrumented.
> Avoiding an escalation is therefore not the same as avoiding the corresponding
> share of total computation, because every input still pays the Phase~1 forward
> pass: the measured Phase~1 cost of 0.000056 GPU-hours per 1{,}000 posts is
> identical at every routing rate. We accordingly report the reduction in
> reasoner invocations and do not convert it into a runtime or monetary saving.

앞뒤 문장("These are fractions of inputs...", "The stress-test routing rate...")은
**그대로 둡니다.** 문단 전체를 지우면 재지 않은 Phase 2까지 잰 것처럼 읽힙니다.

## 10. VIII LIMITATIONS — 첫 문장 교체 【필수】

**현재** ("Computational and explanatory scope." 항목)
> Routing rates show how many posts avoid re-evaluation, but no controlled
> GPU-time, token, or cost comparison was performed.

**교체**
> Phase~1 compute was measured under a controlled benchmark, but Phase~2 was not,
> so the cost of the cascade as a whole is reported as routing volume rather than
> as GPU time. The benchmark also compares our own implementations under one
> serving configuration rather than optimised inference stacks, and a Colab
> runtime is not dedicated hardware, so wall-clock figures carry run-to-run
> variance beyond the discarded warm-up and the three repetitions we report.

뒤따르는 "Generated rationales remain unvalidated explanations..." 이후는 유지합니다.

### 함께 추가할 한 문장 — 탐색 예산 (권장)

같은 항목이나 "Label and population validity" 뒤에 두시면 됩니다.

> The four-trial search budget is small relative to the two-decade learning-rate
> prior used for the probes, so the selected probe configurations, and therefore
> the ordering of the two probes, are sensitive to the draw; the DistilBERT
> selection is not, varying by less than 0.05 accuracy points across repeated
> searches.

**이 문장이 있으면 재현 시 순위가 뒤집혀도 원고가 이미 예고한 범위 안입니다.**
없으면 재현 실패로 읽힙니다.

## 11. Appendix Table A1d 신설 【필수】

Table A1c **바로 뒤**에 둡니다.

> **Appendix Table A1d. Measured Phase 1 cost by stage**
>
> | Stage | Model | Wall-clock (min) | Examples | GPU util (%) | Peak mem (GB) | Energy (Wh) |
> |---|---|---|---|---|---|---|
> | Bayesian search (4 trials) | DistilBERT | 19.03 | — | 54.9 | 4.35 | 62.4 |
> | Training, seeds 42/43/44 | DistilBERT | 5.49 / 5.50 / 5.49 | 252,000 each | 59.1 | 4.35 | 20.4 / 19.4 / 20.4 |
> | Held-out scoring, per seed | DistilBERT | 0.13 | 12,000 | 33–38 | 1.26 | 0.21–0.26 |
> | Batched inference, 3 repetitions | DistilBERT | 0.040 | 12,000 | 57.0 | 0.29 | 0.16 |
> | Single-post inference, 3 repetitions | DistilBERT | 0.042 | 512 | 9.0 | 0.16 | 0.04 |
> | Feature extraction | Llama 2 7B | 38.43 | 108,000 | 93.3 | 27.01 | 234.9 |
> | Bayesian search (4 trials) | Llama 2 7B | 1.59 | — | 5.1 | 1.11 | 1.3 |
> | Head training, per seed | Llama 2 7B | 0.19 | 252,000 | 12.4–12.8 | 1.11 | 0.15 |
> | Batched inference, 3 repetitions | Llama 2 7B | 3.61 | 12,000 | 99.7 | 14.05 | 23.8 |
> | Single-post inference, 3 repetitions | Llama 2 7B | 0.29 | 512 | 55.4 | 13.27 | 0.96 |
> | Feature extraction | Mistral 7B | 40.41 | 108,000 | 93.7 | 29.11 | 255.1 |
> | Bayesian search (4 trials) | Mistral 7B | 1.23 | — | 11.0 | 1.11 | 1.1 |
> | Head training, per seed | Mistral 7B | 0.065 | 168,000 | 10.5–11.5 | 1.11 | 0.04 |
> | Batched inference, 3 repetitions | Mistral 7B | 3.87 | 12,000 | 99.7 | 15.22 | 25.5 |
> | Single-post inference, 3 repetitions | Mistral 7B | 0.32 | 512 | 57.2 | 14.28 | 0.93 |
>
> *Note.* All stages ran on one NVIDIA A100-SXM4-40GB. Timings were taken with
> CUDA synchronisation before and after each timed region; NVML sampled
> utilisation, memory and board power at 1 Hz, and energy is the trapezoidal
> integral of the power samples and covers the GPU board only. Training used bf16
> and inference fp16, both at a 256-token cap. Batched throughput was measured
> over the full 12,000-post held-out split at batch size 32 and single-post
> latency over 512 posts scored one at a time, after discarding three warm-up
> batches; inference rows report the per-repetition figure, and the three
> repetitions agreed to within 0.3% on throughput and 0.6% on median latency. For
> the frozen-backbone probes the training rows cover the linear head only; the
> backbone cost appears in the feature-extraction row and must be added when
> comparing build cost with DistilBERT. Phase 2 generation was not instrumented.

### 이 표에서 반드시 뺄 것

- **두 probe의 held-out scoring 행.** GPU에 상주하는 feature에 선형 head만 곱한 시간이라
  10⁷ examples/s로 기록되어 있습니다. backbone이 빠져 분류기 처리량으로 오독됩니다.
  (위 표에서 이미 제외했습니다.)

  **DistilBERT의 scoring 행은 표에 남겨두되 처리량 열을 비워 두었습니다.** 이 행은
  `trainer.predict()` 경로라 로짓 수집·메트릭 오버헤드가 섞여 있고 batch 64·학습
  정밀도입니다. 같은 모델의 배포 측정(4,959 ex/s)과 3.3배 차이가 나므로, 처리량으로
  읽히면 본문과 충돌합니다. 세 모델의 scoring 행을 처리량 열과 함께 나란히 실으면
  DistilBERT가 probe보다 7,000배 느려 보여 **주장과 정반대 방향으로 읽힙니다.**
- **달러 금액.** $1.1758/GPU-h는 목록가입니다. 넣으신다면 표 아래 한 줄로 근거와
  기준일(2026-09-08)을 함께 밝히세요.

## 12. VI-F EVALUATION METRICS 【권장】

**현재**
> ...interpreted together with model parameter scale and trainable scope; **no
> uncontrolled wall-clock comparison is claimed.**

**교체**
> ...interpreted together with model parameter scale, trainable scope, and the
> controlled cost benchmark reported in Section~VII-A.

## 13. II. STUDY CONTRIBUTIONS 【권장】

첫 항목 마지막 문장("...not to claim exhaustive optimization of every 7B
architecture.") 뒤에 추가.

> That selection is grounded in measured deployment cost as well as accuracy:
> under a controlled benchmark the retained classifier scores posts roughly
> ninety times faster and in a fiftieth of the memory of the 7B comparators.

원고가 서두부터 "an efficient classifier"라고 쓰는데 지금까지 근거가 파라미터 수뿐이었습니다.
심사자가 contribution 목록에서 가장 먼저 검증하려 드는 단어입니다.

---

## 14. 절대 쓰면 안 되는 표현

| 쓰지 말 것 | 이유 | 대신 |
|---|---|---|
| "98.58% reduction in computation / cost" | Phase 2 건당 비용 미측정 | "98.58% reduction in reasoner invocations" |
| "the cascade saves X% GPU time" | 분모(전량 추론 비용) 미측정 | 라우팅 건수까지만 |
| "Mistral outperformed Llama 2" | **CI 중첩** | "the two probes are not separated" |
| "DistilBERT is 89.4× cheaper" (무조건) | 배포 추론 한정. 학습 총액은 0.59 vs 0.68/0.70 | "89.4× less Phase 1 GPU time per post" |
| probe의 scoring 처리량(10⁷/s) | backbone 누락 | `inference_batched`의 55.5 / 51.7 |
| 96.69%를 96.88%로 교체 | 별개의 operational checkpoint | 96.69% 그대로 유지 |

---

## 15. 반영 순서 체크리스트

**A. Table 1 교체**

1. [ ] Table 1 수치 3행 교체 + note에 CI 중첩 문장 추가
2. [ ] VII-A 수치 문단 교체 (1.52 / 1.71 pp, 중첩 문장 포함)
3. [ ] VII-A 오류 구성 문단 교체 (75.6% / 74.3% / 72.8%)
4. [ ] Figure 2 재생성 (96.88 / 95.36 / 95.17, 축 재조정)
5. [ ] Appendix Table A1c 3행 교체
6. [ ] VII-G RQ1b 문장 교체
7. [ ] Abstract 수치 교체

**B. 효율 신설**

8. [ ] Appendix Table A1d 추가 (9번이 참조하므로 먼저)
9. [ ] VII-A 끝에 효율 문단 + 각주
10. [ ] VI-A 마지막 문장 교체 (+ 결정론 문장)
11. [ ] VII-G 효율 문장 교체
12. [ ] VIII Limitations 첫 문장 교체 (+ 탐색 예산 문장)
13. [ ] VI-F 문구 수정
14. [ ] II. Contributions 문장 추가

**C. 확인**

15. [ ] 96.69%가 등장하는 **11곳이 전부 그대로**인지 확인 — Abstract, VII-A, VII-B(1251),
    Table 5(1453–1455), VII-G(1526), 오라클 문단(1609), Figure 6 캡션(1644),
    Conclusion(1808), Appendix A1c note(2063). 모두 downstream이므로 **수정 대상 아님**
16. [ ] V-L "Selecting fewer inputs ... does not by itself quantify latency or monetary savings." **유지**
17. [ ] VI-D "Each W&B Bayesian sweep comprised four trials" **유지** (이번에도 4 trial)
18. [ ] 표기 통일 — 본 문서의 제안 문장은 `±`와 `$\pm$`, `%`와 `\%`가 섞여 있습니다.
    원고의 기존 표기 규칙에 맞춰 일괄 정리하세요
19. [ ] `docs/ieee_access_submission_readiness_checklist_ko.md` 3.2 항목을
    "Phase 1 완료 / Phase 2 미측정"으로 갱신
20. [ ] **`docs/phase1_classifier_results_ko.md`와 `docs/phase1_classifier_results_unified_sweep_ko.md`
    상단에 "이 문서는 이전 실행 기록이며 논문 수치는
    `phase1_gpu_efficiency_benchmark_results_ko.md`를 따른다"고 명시** — 후자는
    "세 구간이 모두 겹치지 않아 순위는 95% 수준에서 분리됩니다"라고 서술하는데, 이번
    실행에서는 두 probe의 구간이 겹치므로 그대로 두면 공저자·검토자에게 상충하는
    자료가 됩니다

---

## 16. 남은 선택지 — Phase 2 비용

`RUN_GENERATION_BENCHMARK = True`로 llama 노트북에서 1회(20~35분) 재면 9번 문장을
"GPU 시간 x% 절감"까지 확장할 수 있고, 본문에 캐스케이드 비용 표를 세울 근거가 생깁니다.
재지 않으실 경우 위 계획을 그대로 쓰시면 되고, 주장 범위가 호출 수로 한정됩니다.
