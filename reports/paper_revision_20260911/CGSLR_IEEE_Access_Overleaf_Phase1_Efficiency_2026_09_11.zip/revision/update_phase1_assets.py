"""Reproduce the revised comparison figure from the final research-team results."""
from pathlib import Path
import csv
import json
import re
import xml.etree.ElementTree as ET

from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

ROOT = Path(__file__).resolve().parent
if not (ROOT / "main.tex").is_file():
    ROOT = ROOT.parent
DATA = [
    dict(model="DistilBERT", mean=96.88, sd=.04, accuracy_ci=[96.79,96.98],
         f1_ci=[96.79,96.98], throughput=4959.5, throughput_sd=15.5,
         p50=4.80, p50_sd=.03, p95=5.11, p95_sd=.12, memory_gb=.29),
    dict(model="Mistral 7B", mean=95.36, sd=.08, accuracy_ci=[95.15,95.57],
         f1_ci=[95.16,95.56], throughput=51.7, throughput_sd=.0,
         p50=36.62, p50_sd=.06, p95=38.37, p95_sd=.18, memory_gb=15.22),
    dict(model="Llama 2 7B", mean=95.17, sd=.07, accuracy_ci=[95.00,95.34],
         f1_ci=[94.99,95.34], throughput=55.5, throughput_sd=.0,
         p50=34.05, p50_sd=.10, p95=36.23, p95_sd=.40, memory_gb=14.05),
]


def update_numbers():
    path = ROOT / "main.tex"
    text = path.read_text()
    for before, after in [
        (r"96.90 $\pm$ 0.12\%", r"96.88 $\pm$ 0.04\%"),
        (r"95.56 $\pm$ 0.11\%", r"95.36 $\pm$ 0.08\%"),
        (r"95.09 $\pm$ 0.06\%", r"95.17 $\pm$ 0.07\%"),
        (r"96.90\%", r"96.88\%"), (r"95.56\%", r"95.36\%"),
        (r"95.09\%", r"95.17\%"),
        ("interpreted together with model parameter scale and trainable scope; no uncontrolled wall-clock comparison is claimed.",
         "interpreted together with model parameter scale, trainable scope, and the common-hardware inference benchmark. Timing variability is reported separately as mean $\\pm$ SD across three measurement repetitions."),
    ]:
        text = text.replace(before, after)
    anchor = "Llama~2~7B frozen-backbone linear probes. The independently fixed"
    if anchor in text:
        text = text.replace(anchor, "Llama~2~7B frozen-backbone linear probes. A common-A100 benchmark also showed substantially higher batched throughput and lower single-post latency for DistilBERT. The independently fixed", 1)
    text = text.replace("No pairwise significance claim is inferred from overlap or non-overlap of the seed-level intervals.", "")
    text = text.replace("operational choice under the bounded comparison, not a ranking of maximally tuned architectures.",
                        "operational choice under the bounded comparison, reinforced by the measured inference advantage, not a ranking of maximally tuned architectures.")
    path.write_text(text)


def figure():
    svg = ROOT / "figures/figure_e_phase1_model_comparison.svg"
    ET.register_namespace("", "http://www.w3.org/2000/svg")
    root = ET.parse(svg).getroot()
    children = list(root)
    count = 0
    y = lambda v: 350 - (v-94.5)/3.0*268
    for index, node in enumerate(children):
        if node.tag.endswith("rect") and node.get("width") == "82":
            row = DATA[count % 3]
            ci = row["accuracy_ci" if count < 3 else "f1_ci"]
            low, high = y(ci[0]), y(ci[1])
            node.set("y", str(y(row["mean"])))
            node.set("height", str(350-y(row["mean"])))
            stem, cap1, cap2, label = children[index+1:index+5]
            stem.set("y1", str(high)); stem.set("y2", str(low))
            for cap, cy in [(cap1,high),(cap2,low)]:
                cap.set("y1",str(cy)); cap.set("y2",str(cy))
            label.set("y",str(high-10)); label.text=f'{row["mean"]:.2f}'
            count += 1
    assert count == 6
    ET.ElementTree(root).write(svg,encoding="unicode")

    fonts = Path("/System/Library/Fonts/Supplemental")
    pdfmetrics.registerFont(TTFont("PaperTimes", str(fonts/"Times New Roman.ttf")))
    pdfmetrics.registerFont(TTFont("PaperTimesBold", str(fonts/"Times New Roman Bold.ttf")))
    out = canvas.Canvas(str(svg.with_suffix(".pdf")), pagesize=(1100,430), invariant=1)
    out.setTitle("Phase 1 classifier comparison: final three-seed results, 2026-09-11")
    sizes = {"tick":17,"axis-label":19,"category":19,"legend":18,"value":17,"note":15}
    for node in root:
        tag = node.tag.rsplit("}",1)[-1]
        if tag not in {"rect","line","text"}: continue
        out.saveState()
        if tag == "rect":
            width = 1100 if node.get("width") == "100%" else float(node.get("width",0))
            height = 430 if node.get("height") == "100%" else float(node.get("height",0))
            out.setFillColor(node.get("fill","#ffffff"))
            if node.get("stroke"):
                out.setStrokeColor(node.get("stroke")); out.setLineWidth(float(node.get("stroke-width",1)))
            out.rect(float(node.get("x",0)),430-float(node.get("y",0))-height,width,height,
                     fill=1,stroke=int(bool(node.get("stroke"))))
        elif tag == "line":
            out.setStrokeColor(node.get("stroke","#000000"))
            out.setLineWidth(float(node.get("stroke-width",1)))
            out.line(float(node.get("x1")),430-float(node.get("y1")),
                     float(node.get("x2")),430-float(node.get("y2")))
        else:
            cls=node.get("class","")
            out.setFont("PaperTimesBold" if cls in {"axis-label","value"} else "PaperTimes",sizes.get(cls,17))
            out.setFillColor("#596168" if cls=="note" else "#252A2E")
            tx,ty=float(node.get("x",0)),430-float(node.get("y",0))
            if node.get("transform"):
                out.translate(tx,ty); out.rotate(90); tx=ty=0
            fn={"middle":out.drawCentredString,"end":out.drawRightString}.get(node.get("text-anchor"),out.drawString)
            fn(tx,ty,node.text or "")
        out.restoreState()
    out.showPage(); out.save()
    (ROOT/"phase1_final_results.json").write_text(json.dumps(DATA,indent=2)+"\n")
    with (ROOT/"phase1_final_results.csv").open("w",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=list(DATA[0])); writer.writeheader(); writer.writerows(DATA)


if __name__ == "__main__":
    update_numbers()
    figure()
