"""Record visual QA and synchronize the final Overleaf review metadata."""
from pathlib import Path
import hashlib
import json
import zipfile

root=Path(__file__).resolve().parent
qa=json.loads((root/'holdout_qa.json').read_text())
qa['visual_review']='All current pages inspected in rendered contact sheets; final appendix inspected separately. No clipping or overlapping text observed. Known template and minor vertical box warnings retained.'
qa['pdf_sha256']=hashlib.sha256((root/'main.pdf').read_bytes()).hexdigest()
(root/'holdout_qa.json').write_text(json.dumps(qa,indent=2)+'\n')
package=root.parent/'CGSLR_IEEE_Access_Overleaf_Focused_2026_09_12.zip'
with zipfile.ZipFile(package) as z:
    entries={i.filename:z.read(i.filename) for i in z.infolist()}
entries['revision/holdout_qa.json']=(root/'holdout_qa.json').read_bytes()
entries['README.md']=(root/'HOLDOUT_README.md').read_bytes()
entries['revision/finalize_holdout.py']=Path(__file__).read_bytes()
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
    for name,content in sorted(entries.items()): z.writestr(name,content)
with zipfile.ZipFile(package) as z:
    assert z.testzip() is None
    assert z.read('main.tex')==(root/'main.tex').read_bytes()
    assert not any('private/' in n or 'predictions.csv' in n for n in z.namelist())
pdf=root.parent/'CGSLR_IEEE_Access_Focused_2026_09_12.pdf'
assert pdf.read_bytes()==(root/'main.pdf').read_bytes()
(root/'holdout_release_sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [pdf,package]},indent=2)+'\n')
print('Final PDF, source ZIP, review documents, and QA metadata synchronized.')
