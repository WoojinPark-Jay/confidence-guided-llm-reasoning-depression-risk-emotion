# IEEE Access manuscript: additional holdout update

Compile `main.tex` with pdfLaTeX in Overleaf. The archive includes the existing figure PDFs and template/font support files. Figure PDFs remain vector/text assets; no screenshot substitution was made.

This 2026-09-12 focused revision retains the completed 9,000-post same-source evaluation, Table 8, and class-wise Appendix F, while moving generation workload and detailed version/seed records out of the manuscript into `revision/REPRODUCIBILITY_RECORD_KO.md`. Original experiments, performance tables, and figures remain unchanged. The current collaborator checklist is `revision/COLLABORATOR_NEXT_STEPS_KO.md`.

Review documents are in `revision/`. Raw post text, row-level predictions, model weights, and private credentials are not included.

This is a collaborator-review version, not a submission-certified manuscript. Author names, affiliations, corresponding-author details, funding/acknowledgment and applicable AI-use disclosure, and biographies still require author completion. The new result is same-source validation, not external-domain or clinical validation.
